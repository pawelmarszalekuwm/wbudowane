#pragma config POSCMOD = XT
#pragma config OSCIOFNC = ON
#pragma config FCKSM = CSDCMD
#pragma config FNOSC = PRI
#pragma config IESO = ON
#pragma config WDTPS = PS32768
#pragma config FWPSA = PR128
#pragma config WINDIS = ON
#pragma config FWDTEN = OFF
#pragma config ICS = PGx2
#pragma config GWRP = OFF
#pragma config GCP = OFF
#pragma config JTAGEN = OFF

#include <xc.h>
#include <libpic30.h>
#include <stdbool.h>
#include "adc.h"
#include "buttons.h"

#define LED_PORT LATA
#define LED_TRIS TRISA
#define ALARM_LED 0x01       // RA0
#define ALARM_THRESHOLD 512  // po?owa z 10-bitowego ADC (0-1023)

void Ports() {
    AD1PCFG = 0xFFFF;      // Wszystkie piny cyfrowe
    LED_TRIS = 0x0000;     // RA jako wyj?cia
    TRISBbits.TRISB3 = 1;  // RB3 jako wej?cie (przycisk)
    TRISD = 0xFFFF;        // RD jako wej?cia (inne przyciski)
}

void ADC() {
    ADC_SetConfiguration(ADC_CONFIGURATION_DEFAULT);
    ADC_ChannelEnable(ADC_CHANNEL_POTENTIOMETER);
}

int main(void) {
    Ports();
    ADC();
    BUTTON_Enable(BUTTON_S3);  // W??cz przycisk S3 (RB3)

    bool alarmActive = false;
    unsigned int blinkStart = 0;

    while (1) {
        uint16_t adcValue = ADC_Read10bit(ADC_CHANNEL_POTENTIOMETER);

        // Sprawd?, czy ADC przekroczy?o pr�g i alarm nie jest aktywny
        if (!alarmActive && adcValue > ALARM_THRESHOLD) {
            alarmActive = true;
            blinkStart = 0;  // Reset licznika migania
        }

        if (alarmActive) {
            // Alarm aktywny - sprawd? czy ADC spad?o poni?ej progu lub przycisk wci?ni?ty
            if (adcValue <= ALARM_THRESHOLD || BUTTON_IsPressed(BUTTON_S3)) {
                // Wy??cz alarm
                LED_PORT = 0x00;
                alarmActive = false;
                while (BUTTON_IsPressed(BUTTON_S3)) __delay32(50000);
                continue;
            }

            if (blinkStart < 5) {
                LED_PORT = (LED_PORT == 0x00) ? ALARM_LED : 0x00;
                __delay32(6000000);
                blinkStart++;
            } else {
                LED_PORT = 0xFF;
            }
        } else {

            LED_PORT = 0x00;
        }

        __delay32(200000);
    }

    return 0;
}
