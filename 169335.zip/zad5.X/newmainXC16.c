#include <xc.h>
#include <libpic30.h>
#include <stdio.h>
#include "lcd.h"
#include "buttons.h"
#include "adc.h"

// KONFIGURACJA
#pragma config POSCMOD = XT
#pragma config OSCIOFNC = ON
#pragma config FCKSM = CSDCMD
#pragma config FNOSC = PRI
#pragma config IESO = ON
#pragma config WDTPS = PS32768
#pragma config FWPSA = PR128
#pragma config WINDIS = ON
#pragma config FWDTEN = OFF
#pragma config ICS = PGx2
#pragma config GWRP = OFF
#pragma config GCP = OFF
#pragma config JTAGEN = OFF

#define FREQ 8000000UL
#define GetSystemClock() FREQ
#define GetInstructionClock() (GetSystemClock()/2)
#define ONE_SECOND (GetInstructionClock())

typedef enum {
    PLAYER_NONE = 0,
    PLAYER_1,
    PLAYER_2
} Player_t;

unsigned int timePlayer1 = 0;
unsigned int timePlayer2 = 0;
Player_t activePlayer = PLAYER_NONE;
int gameRunning = 0;

void InitPorts() {
    AD1PCFG = 0xFFFF; // Wszystkie piny jako cyfrowe domy?lnie
    TRISB = 0xFFFF;   // PORTB jako wej?cia

    BUTTON_Enable(BUTTON_S3); // Przycisk gracza 1 (RB3)
    BUTTON_Enable(BUTTON_S5); // Przycisk gracza 2 (RB5)
}

void InitADC() {
    ADC_SetConfiguration(ADC_CONFIGURATION_DEFAULT);
    ADC_ChannelEnable(ADC_CHANNEL_POTENTIOMETER);
}

// Funkcja zwraca czas startowy w sekundach na podstawie potencjometru
unsigned int GetStartingTimeFromPot() {
    uint8_t potPercent = ADC_ReadPercentage(ADC_CHANNEL_POTENTIOMETER);
    if (potPercent > 66) return 300;  // 5 minut
    else if (potPercent > 33) return 180; // 3 minuty
    else return 60;  // 1 minuta
}

// Wy?wietla czas w formacie mm:ss dla danego gracza
void DisplayActivePlayerTime(unsigned int seconds, Player_t player) {
    char buffer[17];
    int min = seconds / 60;
    int sec = seconds % 60;
    const char *playerStr = (player == PLAYER_1) ? "P1" : "P2";
    sprintf(buffer, "%s %02d:%02d       ", playerStr, min, sec);
    LCD_ClearScreen();
    LCD_PutString(buffer, 16);
}

// Wy?wietla komunikat o przegranej przez czas
void DisplayTimeLoss(Player_t player) {
    LCD_ClearScreen();
    if (player == PLAYER_1) {
        LCD_PutString("P1 przegra?", 12);
    } else if (player == PLAYER_2) {
        LCD_PutString("P2 przegra?", 12);
    }
}

// Wy?wietla ustawiony czas partii przed startem
void DisplayStartingTime(unsigned int seconds) {
    char buffer[17];
    int min = seconds / 60;
    int sec = seconds % 60;
    sprintf(buffer, "Czas: %02d:%02d        ", min, sec);
    LCD_ClearScreen();
    LCD_PutString(buffer, 16);
}

// Sprawdza przyciski i reaguje na nie
void CheckButtons() {
    // Je?li gra nie trwa, wy?wietl czas z potencjometru i czekaj na start
    if (!gameRunning) {
        unsigned int startingTime = GetStartingTimeFromPot();
        DisplayStartingTime(startingTime);

        if (BUTTON_IsPressed(BUTTON_S3)) { // Gracz 1 start
            timePlayer1 = startingTime;
            timePlayer2 = startingTime;
            gameRunning = 1;
            activePlayer = PLAYER_2; // po ruchu P1 zaczyna odliczanie P2
            DisplayActivePlayerTime(timePlayer2, activePlayer);
            while (BUTTON_IsPressed(BUTTON_S3));
            __delay32(50000);
        }
        if (BUTTON_IsPressed(BUTTON_S5)) { // Gracz 2 start
            timePlayer1 = startingTime;
            timePlayer2 = startingTime;
            gameRunning = 1;
            activePlayer = PLAYER_1; // po ruchu P2 zaczyna odliczanie P1
            DisplayActivePlayerTime(timePlayer1, activePlayer);
            while (BUTTON_IsPressed(BUTTON_S5));
            __delay32(50000);
        }
    } else {
        // Je?li gra trwa, przycisk gracza powoduje zmian? aktywnego gracza
        if (BUTTON_IsPressed(BUTTON_S3) && activePlayer == PLAYER_1) {
            activePlayer = PLAYER_2;
            DisplayActivePlayerTime(timePlayer2, activePlayer);
            while (BUTTON_IsPressed(BUTTON_S3));
            __delay32(50000);
        }
        if (BUTTON_IsPressed(BUTTON_S5) && activePlayer == PLAYER_2) {
            activePlayer = PLAYER_1;
            DisplayActivePlayerTime(timePlayer1, activePlayer);
            while (BUTTON_IsPressed(BUTTON_S5));
            __delay32(50000);
        }
    }
}

int main(void) {
    InitPorts();
    LCD_Initialize();
    LCD_CursorEnable(false);
    LCD_ClearScreen();
    LCD_PutString("Zegar SD", 16);

    InitADC();

    __delay32(ONE_SECOND * 2); // 2 sekundy powitania

    while (1) {
        CheckButtons();

        if (gameRunning && activePlayer != PLAYER_NONE) {
            unsigned int i;
            for (i = 0; i < ONE_SECOND / 200000; i++) {
                __delay32(200000);
                CheckButtons(); // sprawdzaj przyciski podczas odliczania
            }

            if (activePlayer == PLAYER_1 && timePlayer1 > 0) {
                timePlayer1--;
                DisplayActivePlayerTime(timePlayer1, PLAYER_1);
                if (timePlayer1 == 0) {
                    DisplayTimeLoss(PLAYER_1);
                    gameRunning = 0;
                    activePlayer = PLAYER_NONE;
                }
            } else if (activePlayer == PLAYER_2 && timePlayer2 > 0) {
                timePlayer2--;
                DisplayActivePlayerTime(timePlayer2, PLAYER_2);
                if (timePlayer2 == 0) {
                    DisplayTimeLoss(PLAYER_2);
                    gameRunning = 0;
                    activePlayer = PLAYER_NONE;
                }
            }
        }
    }

    return 0;
}
