#include <xc.h>
#include <libpic30.h>
#include <stdio.h>      // <- dla sprintf
#include "lcd.h"
#include "buttons.h"

// KONFIGURACJA
#pragma config POSCMOD = XT
#pragma config OSCIOFNC = ON
#pragma config FCKSM = CSDCMD
#pragma config FNOSC = PRI
#pragma config IESO = ON
#pragma config WDTPS = PS32768
#pragma config FWPSA = PR128
#pragma config WINDIS = ON
#pragma config FWDTEN = OFF
#pragma config ICS = PGx2
#pragma config GWRP = OFF
#pragma config GCP = OFF
#pragma config JTAGEN = OFF

#define FREQ 8000000UL
#define GetSystemClock() (FREQ)
#define GetInstructionClock() (GetSystemClock() / 2)
#define ONE_SECOND (GetInstructionClock())

const char* powerLevels[] = { "800W", "600W", "350W", "200W" };
int currentPowerIndex = 0;
unsigned int remainingTime = 0;
int isRunning = 0;

void InitPorts(void) {
    AD1PCFG = 0xFFFF;    // Wszystkie piny jako cyfrowe
    TRISB = 0xFFFF;      // PORTB jako wej?cia

    // Aktywacja przycisk�w z biblioteki
    BUTTON_Enable(BUTTON_S3); // +10 sekund (RB3)
    BUTTON_Enable(BUTTON_S4); // Start/Stop lub Reset (RB2)
    BUTTON_Enable(BUTTON_S5); // Zmiana mocy (RB5)
    BUTTON_Enable(BUTTON_S6); // +1 minuta (RB4)
}

void DisplayStatus(void) {
    char buffer[17];
    LCD_ClearScreen();
    int minutes = remainingTime / 60;
    int seconds = remainingTime % 60;
    sprintf(buffer, "%02d:%02d %s", minutes, seconds, powerLevels[currentPowerIndex]);
    LCD_PutString(buffer, 16);
}

void CheckButtons(void) {
    // Przycisk zmiany mocy (RB5)
    if (BUTTON_IsPressed(BUTTON_S5)) {
        currentPowerIndex = (currentPowerIndex + 1) % 4;
        DisplayStatus();
        while (BUTTON_IsPressed(BUTTON_S5));
        __delay32(50000); // op�?nienie eliminuj?ce drgania
    }

    // Przycisk +1 minuta (RB4)
    if (BUTTON_IsPressed(BUTTON_S6)) {
        remainingTime += 60;
        DisplayStatus();
        while (BUTTON_IsPressed(BUTTON_S6));
        __delay32(50000);
    }

    // Przycisk +10 sekund (RB3)
    if (BUTTON_IsPressed(BUTTON_S3)) {
        remainingTime += 10;
        DisplayStatus();
        while (BUTTON_IsPressed(BUTTON_S3));
        __delay32(50000);
    }

    // Przycisk Start/Stop lub Reset (RB2)
    if (BUTTON_IsPressed(BUTTON_S4)) {
        if (remainingTime == 0) {
            currentPowerIndex = 0;
            isRunning = 0;
            LCD_ClearScreen();
            LCD_PutString("Reset", 5);
            __delay32(8000000); // oko?o 1 sekunda
        } else {
            isRunning = !isRunning;
            LCD_ClearScreen();
            LCD_PutString(isRunning ? "Start" : "Stop", 5);
            __delay32(8000000);
        }
        DisplayStatus();
        while (BUTTON_IsPressed(BUTTON_S4));
        __delay32(50000);
    }
}

int main(void) {
    InitPorts();
    LCD_Initialize();
    LCD_CursorEnable(0);
    LCD_ClearScreen();
    LCD_PutString("Mikrofala", 8);

    __delay32(16000000); // oko?o 2 sekundy
    DisplayStatus();

    while (1) {
        CheckButtons();

        if (isRunning && remainingTime > 0) {
            for (unsigned int i = 0; i < ONE_SECOND / 200000; i++) {
                __delay32(200000);
                CheckButtons(); // Sprawdzaj przyciski podczas pracy
                if (!isRunning) break;
            }

            if (isRunning) {
                remainingTime--;
                DisplayStatus();
            }

            if (remainingTime == 0 && isRunning) {
                LCD_ClearScreen();
                LCD_PutString("Gotowe!", 7);
                isRunning = 0;
            }
        } else {
            __delay32(200000);
        }
    }

    return 0;
}
